</main>
<footer class="site-footer">
<p>&copy; <?php echo date('Y'); ?> Thomas & Effie</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>