
<?php
// [tw_grid cols="3"]Innehåll[/tw_grid]
function tw_grid_shortcode($atts, $content = null) {
    $atts = shortcode_atts([
        'cols' => '3'
    ], $atts);

    $cols_class = 'row row-cols-' . intval($atts['cols']);

    return '<div class="' . esc_attr($cols_class) . '">' . do_shortcode($content) . '</div>';
}
add_shortcode('tw_grid', 'tw_grid_shortcode');
