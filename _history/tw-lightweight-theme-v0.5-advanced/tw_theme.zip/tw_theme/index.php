<?php get_header(); ?>
<h1>Hej världen!</h1>
<?php get_footer(); ?>