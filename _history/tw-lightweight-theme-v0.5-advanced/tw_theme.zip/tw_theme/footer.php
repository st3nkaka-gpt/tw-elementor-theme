<?php
?></main>
<footer class="container py-4">
<p>&copy; <?php echo date('Y'); ?> Thomas & Effie</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>